EnergoIz Android loyihasi (v0.1)

Ushbu ZIP ichida EnergoIz HTML paneli Android WebView ilovasiga joylangan.
Bu hozircha SIMULYATSIYA: ESP32 yoki haqiqiy sensorlarga ulanmagan.

APK yaratish:
1. Kompyuterga Android Studio o‘rnating.
2. Android Studio → Open → ushbu ZIPdan chiqarilgan EnergoIz_Android papkasini tanlang.
3. Gradle sinxronlash tugashini kuting.
4. Build → Build Bundle(s) / APK(s) → Build APK(s).
5. APK odatda app/build/outputs/apk/debug/app-debug.apk manzilida chiqadi.

Eslatma:
- Loyihani qurishda internet orqali Android Gradle Plugin va SDK komponentlari yuklanishi mumkin.
- Ilova internet ruxsatini talab qilmaydi; HTML qurilmaning ichida ishlaydi.
- CSV eksporti ilova ichidagi ulashish oynasi orqali amalga oshirilishi uchun HTMLdagi eksport tugmasini AndroidBridge.shareCsv(...) bilan bog‘lash kerak bo‘lishi mumkin; joriy HTMLning brauzer CSV indirme funksiyasi WebView’da cheklangan bo‘lishi mumkin.
- Haqiqiy elektr tarmog‘iga ulashdan oldin xavfsizlik va o‘lchov sxemasini mutaxassis bilan tekshiring.
